(ns re-hipster-jeans.api-data-generator-test
  (:require [clojure.test :refer :all]
            [clojure.test.check.generators :as gen]
            [clojure.test.check.properties :as prop]
            [clojure.test.check.clojure-test :refer [defspec]]
            )
  (:use [re-hipster-jeans.api-data-generator]))


;; Testing if top result in given grup is greater or equal to all the groups
(defspec top-selling-manufacturers-by-gender-and-country-test
         (prop/for-all [{all-orders :all-orders top :top}
                        (gen/let [all-orders (gen/vector purchase 10)]
                                 {:all-orders all-orders
                                  :top        (top-selling-manufacturers-by-gender-and-country all-orders)})]

                       (let [
                             gender-country-manufacturer-group (into {}
                                                                     (for [[k v] (group-by
                                                                                   #(select-keys % [:gender :country :manufacturer])
                                                                                   all-orders)]
                                                                       [k (->> v (map :order-count) (reduce +))]))

                             top-idx
                             (into {}
                                   (map
                                     #(vector (vec (drop-last 2 %)) (last %))
                                     top))]
                         (is (every?
                               (fn [[k order-count]]
                                 (>= (top-idx [(:gender k) (:country k)]) order-count))
                               gender-country-manufacturer-group)))))

