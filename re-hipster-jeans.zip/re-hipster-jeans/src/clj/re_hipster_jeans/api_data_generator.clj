(ns re-hipster-jeans.api-data-generator
  (:import [org.joda.time DateTime])
  (:require [re-hipster-jeans.data-dict :as d]
            [clojure.pprint :as pp]
            [clj-time.core :as t]
            [clj-time.format :as f]
            [clojure.test.check.generators :as gen]
            [clojure.core.reducers :as r]
            [clojure.string :as s]
            ))

(defmethod print-method DateTime [date out]
  (.write out (str "#date \"" (f/unparse (f/formatters :date) date) "\"")))

(defrecord Orders [order-date country manufacturer gender size color style order-count])

(def gen-country (gen/elements d/countries-of-europe))
(def gen-w-size (gen/elements d/womens-sizes))
(def gen-m-size (gen/elements d/mens-sizes))

(def gen-manufacturers (gen/elements d/manufacturers))
(def gen-jeans-colors (gen/elements d/jeans-colors))
(def gen-jeans-styles (gen/elements d/jeans-styles))

(def first-jan-2016 (t/date-time 2016 1 1))

(def gen-date-of-2016-year
  (gen/fmap #(t/plus first-jan-2016 (t/days %))
            (gen/large-integer* {:min 0 :max 365})))

(def purchase
  (gen/let [gender gen/boolean
            country gen-country
            size (if gender gen-w-size gen-m-size)
            color gen-jeans-colors
            style gen-jeans-styles
            manufacturer gen-manufacturers
            order-count (gen/large-integer* {:min 10 :max 500})
            order-date gen-date-of-2016-year]
           (let [gender-str (if gender "F" "M")]
             (->Orders order-date country manufacturer gender-str size color style order-count)
             )))


(defn generate-purchuases [count]
  (gen/sample purchase count))


(defn hierarhical-sum [a b]
  (if (and (map? a) (map? b))
    (merge-with hierarhical-sum a b)
    (+ a b)))

(defn hierarhical-top [n hierarchy]
  (if (= 1 n)
    (into {} [(apply max-key second hierarchy)])
    (reduce
      (fn [acc [k v]]
        (assoc acc k (hierarhical-top (dec n) v)))
      {}
      hierarchy)))

(defn flatten-map [m]
  (if (map? m)
    (mapcat
      (fn [[k v]]
        (map
          #(cons k %)
          (flatten-map v)))
      m)
    (list (list m))))

(defn top-count-by
  "function creating hierarhical count aggregation of records"
  [records fields count-by]
  (->> records
       (r/fold
         (fn combinef
           ([] {})
           ([a b]
            (merge-with hierarhical-sum a b)))
         (fn reducef [acc order]
           (update-in acc (mapv #(% order) fields) #(+ (count-by order) (or % 0))))
         )
       (hierarhical-top (count fields))
       flatten-map))



(defn top-selling-manufacturers-by-gender-and-country [orders]
  {:rows    (top-count-by orders [:gender :country :manufacturer] :order-count)
   :columns ["gender" "country" "manufacturer" "count"]})

(defn top-selling-sizes-by-country [orders]
  {:rows    (top-count-by orders [:country :size] :order-count)
   :columns ["country" "size" "count"]})

(defn top-selling-months-by-country [orders]
  {:rows    (top-count-by orders [:country #(t/month (:order-date %))] :order-count)
   :columns ["country" "month" "count"]})


(defn generate-api-sham []
  (let [all-orders (vec (generate-purchuases 100000))]
    (do
      (spit "resources/public/api_sham/top-selling-manufacturers-by-gender-and-country.edn" (with-out-str (pp/pprint (top-selling-manufacturers-by-gender-and-country all-orders))))
      (spit "resources/public/api_sham/top-selling-sizes-by-country.edn" (with-out-str (pp/pprint (top-selling-sizes-by-country all-orders))))
      (spit "resources/public/api_sham/top-selling-months-by-country.edn" (with-out-str (pp/pprint (top-selling-months-by-country all-orders)))))))