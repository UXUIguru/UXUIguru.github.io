(ns re-hipster-jeans.data-dict)


(def countries-of-europe
  #{"Albania"
    "Andorra"
    "Armenia"
    "Austria"
    "Azerbaijan"
    "Belarus"
    "Belgium"
    "Bosnia and Herzegovina"
    "Bulgaria"
    "Croatia"
    "Cyprus"
    "Czech Republic"
    "Denmark"
    "Estonia"
    "Finland"
    "France"
    "Georgia"
    "Germany"
    "Greece"
    "Hungary"
    "Iceland"
    "Ireland"
    "Italy"
    "Kazakhstan"
    "Kosovo"
    "Latvia"
    "Liechtenstein"
    "Lithuania"
    "Luxembourg"
    "Macedonia"
    "Malta"
    "Moldova"
    "Monaco"
    "Montenegro"
    "Netherlands"
    "Norway"
    "Poland"
    "Portugal"
    "Romania"
    "Russia"
    "San Marino"
    "Serbia"
    "Slovakia"
    "Slovenia"
    "Spain"
    "Sweden"
    "Switzerland"
    "Turkey"
    "Ukraine"
    "United Kingdom"})


(def womens-sizes
  ;; data from http://www.levi.com/GB/en_GB/about/size-chart/women-international-size-chart
  #{
    "24-25"
    "26-27"
    "28-29"
    "30-31"
    "32-33"
    "33-34"
    "16"
    "18"
    "20"
    "22"
    "24"})

(def mens-sizes
  ;; data http://www.levi.com/GB/en_GB/about/size-chart/men-international-size-chart
  #{
    "28-29"
    "30-31"
    "32-33"
    "34"
    "36"
    "38"
    "40"
    "42"})

(def jeans-styles
  #{
    "Relaxed"
    "Skinny"
    "Slim"
    "Regular"
    "Loose"
    "Boot Cut"})

(def jeans-colors
  #{
    "Dark Blue"
    "Light Blue "
    "Red"
    "Yellow"
    "Black"
    "White"})

(def manufacturers
  #{"The Hipster Jeans Company"
    "Denzil Jeans"
    "Wrangled Jeans"
    "Super Denim Co"
    "Levisos Jeans"})

