(ns re-hipster-jeans.config)

(def debug?
  ^boolean js/goog.DEBUG)
