(ns re-hipster-jeans.db)

(def default-db
  {:name "re-frame"})
